#!/bin/bash
./server -p 13945 -R ./serverRepo
#./server -p 13945 -R ./serverRepo
#./server -p 13945 -R /home/ugrads/majors/zachzaw/p4/pserv/src/serverRepo
