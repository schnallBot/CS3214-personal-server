/*
 * Declarations of various global variables.
 */
#include <stdbool.h>

extern char *server_root;
extern bool silent_mode;
extern int token_expiration_time;
extern bool html5_fallback;
